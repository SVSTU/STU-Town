# Asset vườn ghế riêng

10 GLB cảnh quan, 2 GLB nhân vật, nguồn Blender, layout và ảnh kiểm chứng.
Giải nén theo cấu trúc thư mục tại gốc dự án STU-Town. Đây là gói asset,
không phải toàn bộ ứng dụng hoặc bộ cài server. Các trang viewer dùng các
module JavaScript chung trong repo và cần chạy qua HTTP.

Nguồn: source-assets/private-bench-v1/README.md.
Ảnh tham chiếu AI giữ riêng trong thư mục references của repo, không nhân đôi
trong gói này. Ảnh previews là render/chụp từ mô hình thật.
Khung cổng là GLB; shader xoáy hoạt động trong map Babylon đã tích hợp.
